import sys


FILEPREFIX=sys.argv[1]
Ratio = 100.0
OK=0
out1 = open(FILEPREFIX+".impossibles.bySNP.txt", "w")
out2 = open(FILEPREFIX+".impossibles.byMomOff.txt", "w")
Badcount={}

src  =open(FILEPREFIX+".genotypes.txt", "r") # FILEPREFIX 
for line_idx, line in enumerate(src):
        cols = line.replace('\n', '').split('\t') 

	if line_idx==0:
		currentSNP = cols[0]+"_"+cols[1]
		results=[0,'']
# SNP	0	A	G
# 1	par	1.0	1.0	1.0
# 1	off	0.005	1.0	0.005

	elif cols[0]=="SNP":
		# output results from last snp
		out1.write(currentSNP+'\t'+str(results[0])+'\t'+results[1]+'\n')
		currentSNP = cols[0]+"_"+cols[1]
		results=[0,'']

	elif cols[1]=="par":
		oc = 0
		par=[float(cols[2]),float(cols[3]),float(cols[4])]
		if (par[0] > Ratio*(par[1]+par[2])) or (par[2] > Ratio*(par[1]+par[0])):
			OK=1 # check v off
		else:
			OK=0
	elif (OK==1 and cols[1]=="off"):
		oc+=1
		offg=[float(cols[2]),float(cols[3]),float(cols[4])]
		if (offg[0] > Ratio*(offg[1]+offg[2])): # off is ref homozygote
			if (par[2] > Ratio*(par[1]+par[0])): # mom is alt homo
				results[0]+=1
				results[1]+= cols[0]+","+str(oc)+'\t'
				try:
					Badcount[cols[0]+","+str(oc)]+=1
				except KeyError:
					Badcount[cols[0]+","+str(oc)]=1
		elif (offg[2] > Ratio*(offg[1]+offg[0])): # off is alt homozygote
			if (par[0] > Ratio*(par[1]+par[2])): # mom is ref homo
				results[0]+=1
				results[1]+= cols[0]+","+str(oc)+'\t'
				try:
					Badcount[cols[0]+","+str(oc)]+=1
				except KeyError:
					Badcount[cols[0]+","+str(oc)]=1

# output results from last snp
out1.write(currentSNP+'\t'+str(results[0])+'\t'+results[1]+'\n')

for z in Badcount:
	out2.write(z+'\t'+str(Badcount[z])+'\n')
