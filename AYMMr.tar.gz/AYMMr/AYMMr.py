import sys
from math import log


infile1 = sys.argv[1] # GL.example.txt 
infile2 = sys.argv[2] # key.example.txt 

MinCalls = 10 # require at least this many called plants to include SNP

out1=open("AYMMr.scores.txt","w")

# this is offspring prob given mom and dad
FamProbs={}
for j in range(3): # moms
	FamProbs[j]={}
	for k in range(3): # sires
		FamProbs[j][k]={}
		for x in range(3): # off geno
			FamProbs[j][k][x]=0.0

FamProbs[0][0][0]=1.0 # mom is RR
FamProbs[0][1][0]=0.5
FamProbs[0][1][1]=0.5
FamProbs[0][2][1]=1.0
FamProbs[1][0][0]=0.5 # mom is het
FamProbs[1][0][1]=0.5 
FamProbs[1][1][0]=0.25
FamProbs[1][1][1]=0.5
FamProbs[1][1][2]=0.25
FamProbs[1][2][1]=0.5
FamProbs[1][2][2]=0.5
FamProbs[2][0][1]=1.0 # mom is AA
FamProbs[2][1][1]=0.5
FamProbs[2][1][2]=0.5
FamProbs[2][2][2]=1.0



def PgivenMother(pms,op,mp):
	pm=pms[0]
	qm=1-pm
	ps=pms[1]
	qs=1-ps
	po=(pm+ps)/2.0
	qo=1-po
	prxm=[ pm*pm*mp[0] , 2*qm*pm*mp[1] , qm*qm*mp[2] ]
	prxs=[ ps*ps , 2*qs*ps, qs*qs ]
	prxo=[ po*po*op[0] , 2*qo*po*op[1] , qo*qo*op[2] ]

	prob=0.0
	for j in range(3): # moms
		for k in range(3): # sires
			for x in range(3): # off geno
				prob+= (prxm[j]*prxs[k]*prxo[x]*FamProbs[j][k][x])

	return prob

def PnotMother(pms,op,mp):
	pm=pms[0]
	qm=1-pm
	ps=pms[1]
	qs=1-ps
	po=(pm+ps)/2.0
	qo=1-po
	prxm=[ pm*pm, 2*qm*pm, qm*qm ]
	prxs=[ ps*ps , 2*qs*ps, qs*qs ]
	prxo=[ po*po*op[0] , 2*qo*po*op[1] , qo*qo*op[2] ]

	prob=0.0
	for j in range(3): # moms
		for k in range(3): # sires
			for x in range(3): # off geno
				prob+= (prxm[j]*prxs[k]*prxo[x]*FamProbs[j][k][x])

	prob*=(pm*pm*mp[0]+2.0*qm*pm*mp[1]+qm*qm*mp[2])

	return prob



################################# MAIN PROGRAM ################################


offmom={}
mother_of_family={}
relevant_moms={}
iny=open(infile2, "r")
for line_idx, line in enumerate(iny):
	cols = line.replace('\n', '').split('\t') 
# GL_position	family	ID	type
# 55	2	0	mother
# 16	2	1	offspring
	if line_idx>0:
		if cols[3]=="mother":
			mother_of_family[cols[1]]=int(cols[0])
		elif cols[3]=="offspring":
			offmom[int(cols[0])]=mother_of_family[cols[1]] # given vcf pos of offspring, report vcf pos of mom
			relevant_moms[mother_of_family[cols[1]]]=1
iny.close()

momlist=relevant_moms.keys()

in0=open(infile1,"rU") # 
for line_idx, line in enumerate(in0):
	cols = line.replace('\n', '').split('\t') 

# tolpis_abyss73_8635565_40692_267818	34115	A	G	0.0,1.0,0.0	1,1,1	1.0,0.0997019541328,0.0	0.0,1.0,0.0	1.0,0.216240692204,0.0	1.0,0.3382138792,0.0	1,1,1	1,1,1	1,1,1	1,1,1	1.0,0.0367361477547,0.0	...

	Gprobs={} # this stores the genotype likelihoods for each individual
	QX=[]	# for allele freq estimation
	for j1 in range(4,len(cols)):
		if cols[j1]=="1,1,1":
			Gprobs[j1]=[1,1,1]
		else:
			vv=cols[j1].split(",")
			Gprobs[j1]=[float(vv[0]),float(vv[1]),float(vv[2])]
			if float(vv[0])==max(Gprobs[j1]):
				QX.append(0)
			elif float(vv[1])==max(Gprobs[j1]):
				QX.append(1)
			elif float(vv[2])==max(Gprobs[j1]):
				QX.append(2)
	if len(QX) >= MinCalls:
		Altfreq = 0.5*sum(QX)/float(len(QX))
		pms=[1.0-Altfreq, 1.0-Altfreq]

		SNPscores={"ma":[0,0.0,0.0,0.0],"notma":[0,0.0,0.0,0.0]}

		for offspr in offmom:
			realmom=offmom[offspr]
			oprobs=Gprobs[offspr]
			if oprobs[0]<1 or oprobs[1]<1 or oprobs[1]<1:
				for possiblemom in momlist:
					if possiblemom==realmom:
						ctype="ma"
					else:
						ctype="notma"
					mprobs=Gprobs[possiblemom]
					if mprobs[0]<1 or mprobs[1]<1 or mprobs[1]<1:
						SNPscores[ctype][0]+=1
						p1 = PgivenMother(pms,oprobs,mprobs) # prob of data given that fem is true mom
						p0 = PnotMother(pms,oprobs,mprobs) # prob of data given that this mom is a random individual from population 
						SNPscores[ctype][1]+=log(p1)
						SNPscores[ctype][2]+=log(p0)
						SNPscores[ctype][3]+=(log(p1)-log(p0))

		if SNPscores["ma"][0]>0:
			out1.write(cols[0]+'\t'+cols[1])
			for j in range(4):
				out1.write('\t'+str(SNPscores["ma"][j]))
			for j in range(4):
				out1.write('\t'+str(SNPscores["notma"][j]))
			out1.write('\n')


in0.close()




