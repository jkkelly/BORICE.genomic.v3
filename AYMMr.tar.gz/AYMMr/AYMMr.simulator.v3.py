# Simulate data for Borice-Genomic
# v2 :: introduce errors 
# v3 :: read depth explicit

import sys
from random import random
from random import randint

ReadDepth = int(sys.argv[1])
Frac_wrong = float(sys.argv[2])

rep ="rd"+sys.argv[1]+"er"+sys.argv[2]

SelfingRate = 0.0
FullSib=0 # 0 for half sibs
NumberSNPs = 5000
NumberFams = 20
OffPerFam = 10

ew1=str(0.5**float(ReadDepth))
ew2=str(0.0001)


pltlist=[]
FamPop={}

CRR='\t1.0,'+str(ew1)+','+str(ew2)
CAA='\t'+str(ew2)+','+str(ew1)+',1.0'
CRA='\t'+str(ew2)+',1.0,'+str(ew2)

Q={}
cc=0
for j in range(NumberSNPs):
	cc+=1
	Q[j]=float(cc)/10.0
	if cc==9:
		cc=0


outZ=open(rep+".genotypes.txt","w")
outY=open(rep+".AYMMr.genotypes.txt","w")
out2=open(rep+".outself.txt","w")
out1=open(rep+".key.txt","w")

OFFprobs={"RR.RR":[1,0,0],"RR.RA":[0.5,0.5,0],"RR.AA":[0,1.0,0],"RA.RR":[0.5,0.5,0],"RA.RA":[0.25,0.5,0.25],"RA.AA":[0,0.5,0.5],"AA.RR":[0,1,0],"AA.RA":[0,0.5,0.5],"AA.AA":[0,0,1.0]}

# Main program


os={}
linex=3
out1.write('GL_position\tfamily\tID\ttype\n')
for fx in range(NumberFams):
	linex+=1
	out1.write(str(linex)+'\t'+str(fx+1)+'\t0\tmother\n')
	os[fx+1]={}
	for off in range(OffPerFam):
		if random()<SelfingRate: # offspring selfed
			os[fx+1][off]=1
		else:
			os[fx+1][off]=0

		out2.write(str(fx+1)+'\t'+str(off+1)+'\t'+str(os[fx+1][off])+'\n')
		linex+=1
		out1.write(str(linex)+'\t'+str(fx+1)+'\t'+str(off+1)+'\toffspring\n')



for j in range(NumberSNPs):

# scaffold_8635565_40692_267818	34115	A	G	0.0,1.0,0.0	1,1,1	...
	Qx = Q[j]	
	outZ.write('SNP\t'+str(j)+'\tA\tT\n')
	outY.write('SNP\t'+str(j)+'\tA\tT')
	for fx in range(NumberFams):

		WDraw = random()
		if WDraw<Frac_wrong:
			ry = random()
			if ry < (Qx*Qx):
				matG = 'RR' # truth
				if random()<0.5:
					outZ.write(str(fx+1)+'\t'+ew2+'\t1.0\t'+ew2+'\n')
					outY.write(CRA)
				else:
					outZ.write(str(fx+1)+'\tpar\t'+ew2+'\t'+ew1+'\t1.0\n')
					outY.write(CAA)

			elif ry < ( (Qx*Qx) + 2*Qx*(1-Qx) ):
				matG = 'RA' # truth
				if random()<0.5:
					outZ.write(str(fx+1)+'\tpar\t1.0\t'+ew1+'\t'+ew2+'\n')
					outY.write(CRR)
				else:
					outZ.write(str(fx+1)+'\tpar\t'+ew2+'\t'+ew1+'\t1.0\n')
					outY.write(CAA)
			else:
				matG = 'AA' # truth
				if random()<0.5:
					outZ.write(str(fx+1)+'\tpar\t1.0\t'+ew1+'\t'+ew2+'\n')
					outY.write(CRR)
				else:
					outZ.write(str(fx+1)+'\t'+ew2+'\t1.0\t'+ew2+'\n')
					outY.write(CRA)
		else:
			# maternal plant
			ry = random()
			if ry < (Qx*Qx):
				matG = 'RR'
				outZ.write(str(fx+1)+'\tpar\t1.0\t'+ew1+'\t'+ew2+'\n')
				outY.write(CRR)
			elif ry < ( (Qx*Qx) + 2*Qx*(1-Qx) ):
				matG = 'RA'
				ru = random()
				if ru< 0.5**float(ReadDepth): # all reads R
					outZ.write(str(fx+1)+'\tpar\t1.0\t'+ew1+'\t'+ew2+'\n')
					outY.write(CRR)
				elif ru>= 1.0-0.5**float(ReadDepth):  # all reads A
					outZ.write(str(fx+1)+'\tpar\t'+ew2+'\t'+ew1+'\t1.0\n')
					outY.write(CAA)
				else:
					outZ.write(str(fx+1)+'\tpar\t'+ew2+'\t1.0\t'+ew2+'\n')
					outY.write(CRA)
			else:
				matG = 'AA'
				outZ.write(str(fx+1)+'\tpar\t'+ew2+'\t'+ew1+'\t1.0\n')
				outY.write(CAA)

		if FullSib==0:
			for off in range(OffPerFam):

				WDraw = random()
				if WDraw<Frac_wrong:
					if os[fx+1][off]==1: # offspring selfed
						if matG=='RR':	
							if random()<0.5:
								outZ.write(str(fx+1)+'\toff\t'+ew2+'\t'+ew1+'\t1.0\n')
								outY.write(CAA)
							else:
								outZ.write(str(fx+1)+'\toff\t'+ew2+'\t1.0\t'+ew2+'\n')
								outY.write(CRA)
						elif matG=='AA':
							if random()<0.5:
								outZ.write(str(fx+1)+'\toff\t1.0\t'+ew1+'\t'+ew2+'\n')
								outY.write(CRR)
							else:
								outZ.write(str(fx+1)+'\toff\t'+ew2+'\t1.0\t'+ew2+'\n')
								outY.write(CRA)
						elif matG=='RA':
							ry = random()
							if ry<0.25:
								if random()<0.5:
									outZ.write(str(fx+1)+'\toff\t'+ew2+'\t'+ew1+'\t1.0\n')
									outY.write(CAA)
								else:
									outZ.write(str(fx+1)+'\toff\t'+ew2+'\t1.0\t'+ew2+'\n')
									outY.write(CRA)
							elif ry<0.75:	
								if random()<0.5:
									outZ.write(str(fx+1)+'\toff\t1.0\t'+ew1+'\t'+ew2+'\n')
									outY.write(CRR)
								else:
									outZ.write(str(fx+1)+'\toff\t'+ew2+'\t'+ew1+'\t1.0\n')
									outY.write(CAA)
							else:
								if random()<0.5:
									outZ.write(str(fx+1)+'\toff\t1.0\t'+ew1+'\t'+ew2+'\n')
									outY.write(CRR)
								else:
									outZ.write(str(fx+1)+'\toff\t'+ew2+'\t1.0\t'+ew2+'\n')
									outY.write(CRA)


					else: # offpring outcrossed
						ry = random() # paternal genotype for first fruit
						if ry < Qx: # patG = 'R'

							if matG=='RR':
								if random()<0.5:
									outZ.write(str(fx+1)+'\toff\t'+ew2+'\t'+ew1+'\t1.0\n')
									outY.write(CAA)
								else:
									outZ.write(str(fx+1)+'\toff\t'+ew2+'\t1.0\t'+ew2+'\n')
									outY.write(CRA)				
							elif matG=='AA':
								if random()<0.5:
									outZ.write(str(fx+1)+'\toff\t1.0\t'+ew1+'\t'+ew2+'\n')
									outY.write(CRR)
								else:
									outZ.write(str(fx+1)+'\toff\t'+ew2+'\t'+ew1+'\t1.0\n')
									outY.write(CAA)
							elif matG=='RA':
								rx = random()
								if rx<0.5:
									if random()<0.5:
										outZ.write(str(fx+1)+'\toff\t'+ew2+'\t'+ew1+'\t1.0\n')
										outY.write(CAA)
									else:
										outZ.write(str(fx+1)+'\toff\t'+ew2+'\t1.0\t'+ew2+'\n')
										outY.write(CRA)	
								else:
									if random()<0.5:
										outZ.write(str(fx+1)+'\toff\t1.0\t'+ew1+'\t'+ew2+'\n')
										outY.write(CRR)
									else:
										outZ.write(str(fx+1)+'\toff\t'+ew2+'\t'+ew1+'\t1.0\n')
										outY.write(CAA)

						else: # patG = 'A'
							if matG=='RR':
								if random()<0.5:
									outZ.write(str(fx+1)+'\toff\t1.0\t'+ew1+'\t'+ew2+'\n')
									outY.write(CRR)
								else:
									outZ.write(str(fx+1)+'\toff\t'+ew2+'\t'+ew1+'\t1.0\n')
									outY.write(CAA)
							elif matG=='AA':
								if random()<0.5:
									outZ.write(str(fx+1)+'\toff\t1.0\t'+ew1+'\t'+ew2+'\n')
									outY.write(CRR)
								else:
									outZ.write(str(fx+1)+'\toff\t'+ew2+'\t1.0\t'+ew2+'\n')
									outY.write(CRA)
							elif matG=='RA':
								rx = random()
								if rx<0.5:
									if random()<0.5:
										outZ.write(str(fx+1)+'\toff\t1.0\t'+ew1+'\t'+ew2+'\n')
										outY.write(CRR)
									else:
										outZ.write(str(fx+1)+'\toff\t'+ew2+'\t1.0\t'+ew2+'\n')
										outY.write(CRA)
								else:
									if random()<0.5:
										outZ.write(str(fx+1)+'\toff\t1.0\t'+ew1+'\t'+ew2+'\n')
										outY.write(CRR)
									else:
										outZ.write(str(fx+1)+'\toff\t'+ew2+'\t1.0\t'+ew2+'\n')
										outY.write(CRA)

				else:
					if os[fx+1][off]==1: # offspring selfed
						if matG=='RR':	
							outZ.write(str(fx+1)+'\toff\t1.0\t'+ew1+'\t'+ew2+'\n')
							outY.write(CRR)			
						elif matG=='AA':
							outZ.write(str(fx+1)+'\toff\t'+ew2+'\t'+ew1+'\t1.0\n')
							outY.write(CAA)
						elif matG=='RA':
							ry = random()
							if ry<0.25:
								outZ.write(str(fx+1)+'\toff\t1.0\t'+ew1+'\t'+ew2+'\n')
								outY.write(CRR)
							elif ry<0.75:	

								ru = random()
								if ru < 0.5**float(ReadDepth): # all reads R
									outZ.write(str(fx+1)+'\toff\t1.0\t'+ew1+'\t'+ew2+'\n')
									outY.write(CRR)
								elif ru>= 1.0-0.5**float(ReadDepth):  # all reads A
									outZ.write(str(fx+1)+'\toff\t'+ew2+'\t'+ew1+'\t1.0\n')
									outY.write(CAA)
								else:
									outZ.write(str(fx+1)+'\toff\t'+ew2+'\t1.0\t'+ew2+'\n')
									outY.write(CRA)


							else:
								outZ.write(str(fx+1)+'\toff\t'+ew2+'\t'+ew1+'\t1.0\n')
								outY.write(CAA)

					else: # offpring outcrossed
						ry = random() # paternal genotype for first fruit
						if ry < Qx: # patG = 'R'

							if matG=='RR':
								outZ.write(str(fx+1)+'\toff\t1.0\t'+ew1+'\t'+ew2+'\n')
								outY.write(CRR)				
							elif matG=='AA':
								ru = random()
								if ru < 0.5**float(ReadDepth): # all reads R
									outZ.write(str(fx+1)+'\toff\t1.0\t'+ew1+'\t'+ew2+'\n')
									outY.write(CRR)
								elif ru>= 1.0-0.5**float(ReadDepth):  # all reads A
									outZ.write(str(fx+1)+'\toff\t'+ew2+'\t'+ew1+'\t1.0\n')
									outY.write(CAA)
								else:
									outZ.write(str(fx+1)+'\toff\t'+ew2+'\t1.0\t'+ew2+'\n')
									outY.write(CRA)

							elif matG=='RA':
								rx = random()
								if rx<0.5:
									outZ.write(str(fx+1)+'\toff\t1.0\t'+ew1+'\t'+ew2+'\n')
									outY.write(CRR)
								else:
									ru = random()
									if ru < 0.5**float(ReadDepth): # all reads R
										outZ.write(str(fx+1)+'\toff\t1.0\t'+ew1+'\t'+ew2+'\n')
										outY.write(CRR)
									elif ru>= 1.0-0.5**float(ReadDepth):  # all reads A
										outZ.write(str(fx+1)+'\toff\t'+ew2+'\t'+ew1+'\t1.0\n')
										outY.write(CAA)
									else:
										outZ.write(str(fx+1)+'\toff\t'+ew2+'\t1.0\t'+ew2+'\n')
										outY.write(CRA)

						else: # patG = 'A'
							if matG=='RR':
								ru = random()
								if ru < 0.5**float(ReadDepth): # all reads R
									outZ.write(str(fx+1)+'\toff\t1.0\t'+ew1+'\t'+ew2+'\n')
									outY.write(CRR)
								elif ru>= 1.0-0.5**float(ReadDepth):  # all reads A
									outZ.write(str(fx+1)+'\toff\t'+ew2+'\t'+ew1+'\t1.0\n')
									outY.write(CAA)
								else:
									outZ.write(str(fx+1)+'\toff\t'+ew2+'\t1.0\t'+ew2+'\n')
									outY.write(CRA)
							elif matG=='AA':
								outZ.write(str(fx+1)+'\toff\t'+ew2+'\t'+ew1+'\t1.0\n')
								outY.write(CAA)
							elif matG=='RA':
								rx = random()
								if rx<0.5:
									ru = random()
									if ru < 0.5**float(ReadDepth): # all reads R
										outZ.write(str(fx+1)+'\toff\t1.0\t'+ew1+'\t'+ew2+'\n')
										outY.write(CRR)
									elif ru>= 1.0-0.5**float(ReadDepth):  # all reads A
										outZ.write(str(fx+1)+'\toff\t'+ew2+'\t'+ew1+'\t1.0\n')
										outY.write(CAA)
									else:
										outZ.write(str(fx+1)+'\toff\t'+ew2+'\t1.0\t'+ew2+'\n')
										outY.write(CRA)
								else:
									outZ.write(str(fx+1)+'\toff\t'+ew2+'\t'+ew1+'\t1.0\n')
									outY.write(CAA)

	outY.write('\n')




