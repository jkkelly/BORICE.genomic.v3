from scipy.stats import f_oneway
import sys
from random import shuffle

reps = 10000

infile = sys.argv[1] # Macro

out2 =open("Permutation.results.txt", "w") # 

data={}
yij = []
in1=open(infile, "r")
for line_idx, line in enumerate(in1):
        cols = line.replace('\n', '').split('\t') 

# Population	Probability_outcrossed	
# 1	1
# 1	0.011

	if line_idx>0:
		try:
			data[cols[0]].append(float(cols[1]))
		except KeyError:
			data[cols[0]]=[float(cols[1])]

		yij.append(float(cols[1]))

x=[]
for pop in data:
	x.append(data[pop])
# peform anova on original data
F_real,p=f_oneway(*x)
print "real data F, p",F_real,p
out2.write("Real\t"+str(F_real)+"\t"+str(p)+"\n") 

pval=0.0
for rp in range(reps):
	shuffle(yij)
	cx=0
	for pop in data:
		for j in range(len(data[pop])):
			data[pop][j]=yij[cx]
			cx+=1
	x=[]
	for pop in data:
		x.append(data[pop])
	f,p=f_oneway(*x)
	# print rp," F, p",f,p
	out2.write(str(rp)+"\t"+str(f)+"\t"+str(p)+"\n") 
	if f>F_real:
		pval+= 1.0/float(reps)

print "Permutation p-value ",pval

